# Backend

This directory will contain the backend code for the Online Note Taking App.

Features:
- CRUD APIs for notes
- JWT authentication
- Notes sorted by update time
- (Optional) Public/private toggle for notes
